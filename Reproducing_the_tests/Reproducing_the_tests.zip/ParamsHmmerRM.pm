# Developed by Carlos Fischer - 11.01.2021

# Parameters used in "extractHmmerRM.pl" and "finalCandidsHmmerRM.pl" scripts.

# DO NOT CHANGE/COMMENT ANYTHING HERE

###########################################################################################

package ParamsHmmerRM;
# ParamsHmmerRM.pm

use strict;
use warnings;

use Exporter qw(import);
our @EXPORT_OK = qw($varExtr $minOverlPred $maxOverlCand $distPredsHMMER $distPredsRepeatMasker $minLenPred $minSwscore $pattLtrs $includeLTRs);


####### used in "extractHmmerRM.pl":
our $varExtr = 50;
our $minOverlPred = 100;

####### used in "finalCandidsHmmerRM.pl":
our $maxOverlCand   = 100;

our $distPredsHMMER = 300;


our $distPredsRepeatMasker = 500;
our $minLenPred            = 10;
our $minSwscore            = 500;

our $pattLtrs    = ("-LTR|_LTR"); 
our $includeLTRs = "no"; 

