# Developed by Carlos Fischer - 30.09.2022
# Used to launch the necessary scripts to reproduce the results described in the main text
# Usage: perl reproducingTests.pl

##############
# WARNING: THIS SCRIPT IS TO BE USED **ONLY** TO REPRODUCE THE RESULTS DESCRIBED IN THE MAIN TEXT
##############


# scripts to be launched by reproducingTests.pl:

print "Extracting predictions from HMMER ...\n";
system("perl extractHmmerRM_HMMER.pl");

print "\nExtracting predictions from RepeatMasker ...\n";
system("perl extractHmmerRM_RM.pl");

print "\nExtracting predictions from RPS-Blast ...\n";
system("perl extractRPSB.pl");


print "\nRunning CombTEs ...\n";
system("perl CombTEs.pl");
 
print "\nRunning compareGroupsDmel ...\n";
system("perl compareGroupsDmel.pl");
print "\nRunning compareGroupsDmelGoodMetrics ...\n";
system("perl compareGroupsDmelGoodMetrics.pl");

print "\nDone!\n\n";


