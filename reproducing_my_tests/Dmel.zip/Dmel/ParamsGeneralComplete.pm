# Developed by Carlos Fischer - 11.01.2021
# General parameters used in all scripts.

##############
# WARNING: THIS PACKAGE IS TO BE USED **ONLY** FOR THE TESTS FOR THE pHMMs CALLED "COMPLETE" ("SUPERFAM_complet.hmm).
##############

# DO NOT CHANGE/COMMENT ANYTHING HERE

###########################################################################################

package ParamsGeneralComplete;
# ParamsGeneralComplete.pm

use strict;
use warnings;

use Exporter qw(import);

our @EXPORT_OK = qw(@superfamilies @combClassif $usingSubseqs $overlap $limit @tools @outFileNames @otherTools %outFileNamesOthers %filterTools %filterOtherTools %goodMetrTools %goodMetrOtherTools $distBetweenCands);


our @superfamilies = ("Bel", "Copia", "Gypsy");
our @combClassif = (@superfamilies, "inconclusive", "Bel/Copia", "Bel/Gypsy", "Copia/Gypsy", "Bel/Copia/Gypsy");


our $usingSubseqs = "yes";
my  $lengthSubseq = 10000;
our $overlap      = 1000;
our $limit        = $lengthSubseq - $overlap;

our @tools = ("HMMER");
our @outFileNames  = ("ONE");

our @otherTools = ();
our %outFileNamesOthers = ();

our %filterTools = ();
$filterTools{'HMMER'} = 1.0e-05;
our %filterOtherTools = ();

our %goodMetrTools = ();
$goodMetrTools{'HMMER'} = 1.0e-50;
our %goodMetrOtherTools = ();

our $distBetweenCands = 500;

