# Developed by Carlos Fischer - 11.01.2021
# General parameters used in all scripts.

##############
# WARNING: THIS PACKAGE IS TO BE USED **ONLY** FOR THE TESTS FOR THE pHMMs CALLED "COMPLETE" ("SUPERFAM_complet.hmm).
##############

# DO NOT CHANGE/COMMENT ANYTHING HERE

###########################################################################################

package ParamsGeneralComplete;
# ParamsGeneralComplete.pm

use strict;
use warnings;

use Exporter qw(import);

# When using also other tools, use the following "@EXPORT_OK":
our @EXPORT_OK = qw(@superfamilies @combClassif $usingSubseqs $overlap $limit @tools @outFileNames @otherTools %outFileNamesOthers %filterTools %filterOtherTools %goodMetrTools %goodMetrOtherTools $distBetweenCands);


our @superfamilies = ("Bel", "Copia", "Gypsy");
our @combClassif = (@superfamilies, "inconclusive", "Bel/Copia", "Bel/Gypsy", "Copia/Gypsy", "Bel/Copia/Gypsy");


our $usingSubseqs = "yes";
my  $lengthSubseq = 10000; # length of the subsequences.
our $overlap      = 1000;  # length of the overlap region.
our $limit        = $lengthSubseq - $overlap;

# DO NOT CHANGE ANYTHING HERE
our @tools = ("HMMER"); # FOR "COMPLETE" pHMMs
our @outFileNames  = ("ONE"); # when using only HMMER

our @otherTools = (); # DO NOT COMMENT THIS LINE.

our %outFileNamesOthers = (); # DO NOT COMMENT THIS LINE.

our %filterTools = ();
$filterTools{'HMMER'} = 1.0e-05;

our %filterOtherTools = (); # DO NOT COMMENT THIS LINE.


# DO NOT CHANGE/COMMENT ANYTHING HERE
our %goodMetrTools = ();
$goodMetrTools{'HMMER'}        = 1.0e-50;

our %goodMetrOtherTools = (); # DO NOT COMMENT THIS LINE.


our $distBetweenCands = 500; # maximum distance from a candidate to the next one to consider them inside a SAME FINAL GROUP.


