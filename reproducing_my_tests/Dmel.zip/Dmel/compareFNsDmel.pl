# Developed by Carlos Fischer - 11.01.2021
# Used to compare FNs from each method in each chromosome
# Usage: perl compareFNsDmel.pl

##############
# WARNING: THIS SCRIPT IS TO BE USED **ONLY** TO REPRODUCE THE RESULTS DESCRIBED IN THE MAIN TEXT AND THE SUPPLEMENTARY MATERIAL FILE
##############

# The results produced here are used to generate Tables S1-S2


##############################################
@usedFiltersHMMER = (100, 1.0e-05, 1.0e-10, 1.0e-15, 1.0e-20, 1.0e-30, 1.0e-40, 1.0e-05, 1.0e-10, 1.0e-20, 1.0e-30);
@usedFiltersRM    = (225, 230, 250, 280, 310, 350, 410, 400, 420, 460, 500);
$qttFiltersHMMER = scalar(@usedFiltersHMMER);
$qttFiltersRM    = scalar(@usedFiltersRM);
if ($qttFiltersHMMER != $qttFiltersRM) { die "NO MATCH IN NUMBERS OF FILTERS!!"; }

$minOverl = 30;

$tool1 = "HMMER";
$tool2 = "RepeatMasker";

@chromosomes = ("2L", "2R", "3L", "3R", "4", "X");

$anotados{"2L"} = 313;
$anotados{"2R"} = 1334;
$anotados{"3L"} = 1195;
$anotados{"3R"} = 970;
$anotados{"4"}  = 35;
$anotados{"X"}  = 315;
##############################################


for ($iFilt = 0; $iFilt < $qttFiltersHMMER; $iFilt++) {

    $filterHMM = $usedFiltersHMMER[$iFilt];
    $filterRM  = $usedFiltersRM[$iFilt];

    print "$filterHMM and $filterRM:\n";

    $outGeral = "X_Tables_S1-S2/Summary_FNs_$tool1\_$filterHMM-$tool2\_$filterRM.cmp";
    open (OUTGERAL,">$outGeral") || die "Can't open $outGeral\n";
    print OUTGERAL "Summary of FN comparison from \"$tool1\" and \"$tool2\" tools\n";
    print OUTGERAL "Used filters: **$tool1 = $filterHMM** and **$tool2 = $filterRM**\n\n";

    $totalGeralAnotados = 0;
    $totalGeralFNs1 = 0;
    $totalGeralFNs2 = 0;
    $totalGeralFNsComuns = 0;
    $totalGeralFNsExcl1  = 0;
    $totalGeralFNsExcl2  = 0;
    $totalGeralTPsComuns = 0;
    $totalGeralTPsExcl   = 0;


    foreach $chromo (@chromosomes) {
	print "\t$chromo\n";

	$comp1 = "Results_$tool1/XX_comparedCandidates_$tool1-$chromo-$filterHMM.cmp";
	open (COMP1, $comp1) || die "Can't open $comp1";

	$line = readline(COMP1); chomp $line;
	while ($line !~ /TRUE ANNOTATED NOT PREDICTED/) { $line = readline(COMP1); }
	@fns1 = ();
	$line = readline(COMP1);
	while ($line ne "\n") {
		push (@fns1, $line);
		$line = readline(COMP1);
	}
	close(COMP1);

	$comp2 = "Results_$tool2/XX_comparedCandidates_$tool2-$chromo-$filterRM.cmp";
	open (COMP2, $comp2) || die "Can't open $comp2";

	$line = readline(COMP2); chomp $line;
	while ($line !~ /TRUE ANNOTATED NOT PREDICTED/) { $line = readline(COMP2); }
	@fns2 = ();
	$line = readline(COMP2);
	while ($line ne "\n") {
		push (@fns2, $line);
		$line = readline(COMP2);
	}
	close(COMP2);

	$qtt1 = scalar(@fns1);
	$qtt2 = scalar(@fns2);

	$totalGeralFNs1 += $qtt1;
	$totalGeralFNs2 += $qtt2;

	@comuns = ();
	foreach $fn1 (@fns1) {
#		Annot---CHROMO--cr---FROM--ff---TO--tt---LENGTH--ll---SENSE--d/r---CLASSIF--cl----->FBti0060580   Idefix{}2519
		if ($fn1 =~ /CLASSIF--(\w+)----->(.*)\n/) {
			$id1 = $2;
			foreach $fn2 (@fns2) {
				if ($fn2 =~ /CLASSIF--(\w+)----->(.*)\n/) {
					$id2 = $2;
					if ($id1 eq $id2) { push (@comuns, $fn2); }
				}
			}
		}
	} # FOREACH $fn1 (@fns1)

	@exclusivos1 = ();
	foreach $fn1 (@fns1) {
		if ($fn1 =~ /CLASSIF--(\w+)----->(.*)\n/) {
			$id1 = $2;
			$ehComum = "nao";
			foreach $comum (@comuns) {
				if ($comum =~ /CLASSIF--(\w+)----->(.*)\n/) {
					$idCom = $2;
					if ($id1 eq $idCom) { $ehComum = "sim"; }
				}
			}
			if ($ehComum eq "nao") { push (@exclusivos1, $fn1); }
		}
	} # FOREACH $fn1 (@fns1)

	@exclusivos2 = ();
	foreach $fn2 (@fns2) {
		if ($fn2 =~ /CLASSIF--(\w+)----->(.*)\n/) {
			$id2 = $2;
			$ehComum = "nao";
			foreach $comum (@comuns) {
				if ($comum =~ /CLASSIF--(\w+)----->(.*)\n/) {
					$idCom = $2;
					if ($id2 eq $idCom) { $ehComum = "sim"; }
				}
			}
			if ($ehComum eq "nao") { push (@exclusivos2, $fn2); }
		}
	} # FOREACH $fn2 (@fns2)

	$qttComuns = scalar(@comuns);
	$qttExcl1  = scalar(@exclusivos1);
	$qttExcl2  = scalar(@exclusivos2);

	$TPsComums = $anotados{$chromo} - $qttComuns;
	$TPsExcl = $qttExcl1 + $qttExcl2;

	$totalGeralFNsComuns += $qttComuns;
	$totalGeralFNsExcl1  += $qttExcl1;
	$totalGeralFNsExcl2  += $qttExcl2;
	$totalGeralAnotados  += $anotados{$chromo};

	$totalGeralTPsComuns += $TPsComums;
	$totalGeralTPsExcl   += $TPsExcl;


	$out = "X_FNs/FNs_$chromo\_$tool1\_$filterHMM-$tool2\_$filterRM.cmp";
	open (OUT,">$out") || die "Can't open $out";

	print OUT "For chromo $chromo:\n";
	print OUT "\tTotal of annotation = $anotados{$chromo}\n";
	print OUT "\tTotal of FNs for $tool1 = $qtt1\n";
	print OUT "\tTotal of FNs for $tool2 = $qtt2\n\n";

	print OUT "*** FNs COMMON for the 2 tools (total: $qttComuns):\n";
	foreach $comum (@comuns) { print OUT $comum; }
	print OUT "\n\n";

	print OUT "*** FNs exclusive of $tool1 (total: $qttExcl1):\n";
	foreach $excl1 (@exclusivos1) { print OUT $excl1; }
	print OUT "\n\n";

	print OUT "*** FNs exclusive of $tool2 (total: $qttExcl2):\n";
	foreach $excl2 (@exclusivos2) { print OUT $excl2; }

	close (OUT);

	print OUTGERAL "CHROMO $chromo:\n";
	print OUTGERAL "\tTotal of annotation: $anotados{$chromo}\n";
	print OUTGERAL "\tTotal of FNs of:\n";
	print OUTGERAL "\t\t$tool1: $qtt1\n";
	print OUTGERAL "\t\t$tool2: $qtt2\n\n";
	print OUTGERAL "\tFNs COMMON: $qttComuns\n";
	print OUTGERAL "\tFNs EXCLUSIVE of:\n";
	print OUTGERAL "\t\t$tool1: $qttExcl1\n";
	print OUTGERAL "\t\t$tool2: $qttExcl2\n\n";

	print OUTGERAL "\tTotal of TPs of the 2 tools together: $TPsComums";
	print OUTGERAL ", being $TPsExcl TPs EXCLUSIVE of each tool.\n\n\n";

    } # FOREACH $chromo (@chromosomes)

    print OUTGERAL "**************************\n\n";
    print OUTGERAL "General total of annotation: $totalGeralAnotados\n\n";

    print OUTGERAL "General total of FNs for:\n";
    print OUTGERAL "\t$tool1: $totalGeralFNs1\n";
    print OUTGERAL "\t$tool2: $totalGeralFNs2\n\n";

    print OUTGERAL "General total of COMMON FNs: $totalGeralFNsComuns\n\n";

    print OUTGERAL "General total of FNs EXCLUSIVE of:\n";
    print OUTGERAL "\t$tool1: $totalGeralFNsExcl1\n";
    print OUTGERAL "\t$tool2: $totalGeralFNsExcl2\n\n";

    print OUTGERAL "General total of TPs for the 2 tools together: $totalGeralTPsComuns, being $totalGeralTPsExcl TPs EXCLUSIVE of each tool.\n\n";

    $porcTPsExclHMMs = int( ($totalGeralFNsExcl2/$totalGeralTPsComuns) * 10000 )/100;
    $porcTPsExclRM   = int( ($totalGeralFNsExcl1/$totalGeralTPsComuns) * 10000 )/100;

    print OUTGERAL "From $totalGeralTPsComuns TPs together, $totalGeralFNsExcl2 ($porcTPsExclHMMs%) were predicted only by HMMER and $totalGeralFNsExcl1 ($porcTPsExclRM%) only by RepeatMasker.\n\n";

    close (OUTGERAL);

} # FOR ($iFilt = 0; $iFilt < $qttFiltersHMMER; $iFilt++)

