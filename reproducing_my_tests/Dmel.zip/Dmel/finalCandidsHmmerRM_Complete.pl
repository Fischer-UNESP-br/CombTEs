# Developed by Carlos Fischer - 11.01.2021
# To generate the final candidates of HMMER, for all superfamilies.
# It generates also a separate file with the candidates for each superfamily of HMMER, for each chromosome

# Usage: perl finalCandidsHmmerRM_Complete.pl HMMER CHROMO FILTER

##############
# WARNING: THIS SCRIPT IS TO BE USED **ONLY** TO REPRODUCE THE RESULTS DESCRIBED IN THE MAIN TEXT AND THE SUPPLEMENTARY MATERIAL FILE RELATED TO HMMER, CONSIDERING THE pHMMs CALLED "COMPLETE" ("SUPERFAM_complet.hmm)
##############

# It generates initial results used to produce the "Conventional pHMMs" column of Table S1

# It is launched by CombTEs_Complete.pl


###########################################################################################

use strict;
use warnings;

use Cwd qw(getcwd);
use lib getcwd(); 

use ParamsGeneralComplete qw(@superfamilies %filterTools);
use ParamsHmmerRM qw($varExtr $minOverlPred $maxOverlCand $distPredsHMMER);

###########################################################################################


sub verifyOverlap { # to verify overlap between 2 candidates and, if so, retrieve an ID of the one to be disregarded; this candidate would be:
# - for HMMER:        the one with the highest e-value or, for the same e-values, the shortest candidate

	(my $method, my $seq1, my $seq2) = @_;

	my ($from1, $to1, $length1, $evalSWs1, $sense1);
	my ($from2, $to2, $length2, $evalSWs2, $sense2);

# For HMMER:
# $seq= Candidate_1 - FROM: ff - TO: tt - LENGTH: ll - EVALUE: ev - SENSE: dr - CLASSIFICATION: spfam\nPREDIC---FROM-- etc.
	if (
	     ($seq1 =~ /FROM: (.*) - TO: (.*) - LENGTH: (.*) - (EVALUE): (.*) - SENSE: (.*) - CLASSIFICATION/)
	   ) {
		$from1    = $1;
		$to1      = $2;
		$length1  = $3;
		$evalSWs1 = $5;
		$sense1   = $6;
	}
	if (
	     ($seq2 =~ /FROM: (.*) - TO: (.*) - LENGTH: (.*) - (EVALUE): (.*) - SENSE: (.*) - CLASSIFICATION/)
	   ) {
		$from2    = $1;
		$to2      = $2;
		$length2  = $3;
		$evalSWs2 = $5;
		$sense2   = $6;
	}

	my $respOverl = "NONE"; # there is NOT overlap between seq_1 and seq_2 OR retrieve an ID of the prediction to be disregarded
	if ($sense1 eq $sense2) {
	    if ( ($from2 <= $to1) or ($to2 >= $from1) ) {
		if (
		    (abs($from1-$from2) <= $varExtr) or (abs($to1-$to2) <= $varExtr) or # small variation in corresponding extremities
		    (($from1 < $from2) and ($to2 <  $to1)) or				# seq_2 inside seq_1
		    (($from2 < $from1) and ($to1 <  $to2)) or				# seq_1 inside seq_2
		    (($from1 < $from2) and (($to1 - $from2) >= $maxOverlCand)) or	# overlap >= $maxOverlCand
		    (($to2   < $to1)   and (($to2 - $from1) >= $maxOverlCand))
		   ) { # there is overlap between seq_1 and seq_2
			if ($method eq "HMMER") {
				if    ($evalSWs1 < $evalSWs2) { $respOverl = "JJ"; }
				elsif ($evalSWs1 > $evalSWs2) { $respOverl = "II"; }
				else {
					if ($length1 >= $length2) { $respOverl = "JJ"; }	
					else			  { $respOverl = "II"; }
				} 
			}
		} # IF ( (abs($from1-$from2) <= $varExtr) or ....
	    } # IF ( ($from2 < $to1) or ($to2 > $from1) )
	} # IF ($sense1 eq $sense2)

	return ($respOverl, $sense1, $sense2);
} # END of SUB "verifyOverlap"

###########################################################################################

my $tool       = $ARGV[0];
my $chromo     = $ARGV[1];
my $usedFilter = $ARGV[2];

my ($metrics, $maxDistPreds);
if ($tool eq "HMMER") {
	$metrics = "EVALUE";
	$maxDistPreds = $distPredsHMMER;
}

my @candidAllSuperfam = (); # for all candidates of each tool for FINAL classification

foreach my $superfam (@superfamilies) {
	my $inPred = "Results_$tool/$superfam/$superfam\_$tool";

   	my $predFile = "$inPred-$chromo-Complete.pred"; # file with predictions of each superfamily from HMMER
   	open (PREDFILE, $predFile) or die "Can't open $predFile!!!";

	my $toolCandids = "Results_$tool/finalCandidates_$tool-$chromo-Complete_$usedFilter.txt";
	open (TOOLCANDIDS, ">$toolCandids") or die "Can't open $toolCandids";

	my $spfamCandids = "$inPred-candidates-$chromo-Complete_$usedFilter.pred"; # for the candidates of each superfamily
	open (SPFAMCANDIDS, ">$spfamCandids") or die "Can't open $spfamCandids!!!";
	print SPFAMCANDIDS "Candidates of $tool for \*$superfam\* superfamily, from file \"$predFile\".\n";
	print SPFAMCANDIDS "Maximum distance between two predictions to consider them inside the same candidate: $maxDistPreds.\n";
	if    ($tool eq "HMMER") { print SPFAMCANDIDS "Filter for e-values: $usedFilter.\n\n"; }

### filtering predictions based on e-values for HMMER
	my @candidSuperfam = ();
	while (not eof PREDFILE) {
		my $line = readline(PREDFILE); chomp $line;
# from the input files:
# from HMMER:	PREDIC---FROM--ff---TO--tt---LENGTH--ll---EVALUE--ev---SCORE--sc---SENSE--d/r---SUPERFAM--sf

		if ($line =~ /EVALUE--(.*)---SCORE/) {
			my $evalue = $1;
			if ($evalue <= $usedFilter) { push (@candidSuperfam, $line); }
		}
	} # WHILE
### END of filtering predictions
	close (PREDFILE);

## generating candidates of EACH superfamily (for each tool)
	my $qttSpfam = scalar(@candidSuperfam);
	my $newCandid = "yes";
	my $numCandid = 0;
	my $i = 0;
	my ($from, $to, $evalSws, $sense, $startCandid, $endCandid, $evalSwsCand, $senseCandid);
	my @arrayPrint;
	while ($i < $qttSpfam) {
		my $lineSpf = $candidSuperfam[$i];
		if ($lineSpf =~ /FROM--(\d+)---TO--(\d+)---LENGTH/) {
			$from = $1;
			$to   = $2;
		}
		if ($lineSpf =~ /EVALUE--(.*)---SCORE--.*---SENSE--(.*)---SUPERFAM/) {
			$evalSws = $1;
			$sense   = $2;
		}
		elsif ($lineSpf =~ /SWSCORE--(\d+)---SENSE--(.*)---MATCHINGREPEAT/) {
			$evalSws = $1;
			$sense   = $2;
		}

		if ($newCandid eq "yes") {
			$startCandid = $from;
			$endCandid   = $to;
			$evalSwsCand = $evalSws;
			$senseCandid = $sense;

			@arrayPrint = ();
			push (@arrayPrint, $lineSpf);
			$newCandid = "no";
			$i++;
		}
		else { # ($newCandid eq "NO")
			if ( ($sense eq $senseCandid) and (($from - $endCandid) <= $maxDistPreds) ) {
				if ($to > $endCandid) { $endCandid = $to; }
				if ($tool eq "HMMER") { if ($evalSws < $evalSwsCand) { $evalSwsCand = $evalSws; } }
				push (@arrayPrint, $lineSpf);
				$i++;
			}
			else { $newCandid = "yes"; }
		}

		if ( ($newCandid eq "yes") or ($i == $qttSpfam) ) {
			$numCandid++;
			my $lengthCandid = $endCandid - $startCandid + 1;
			my $idCandid = "Candidate_$numCandid - FROM: $startCandid - TO: $endCandid - LENGTH: $lengthCandid - $metrics: $evalSwsCand - SENSE: $senseCandid - CLASSIFICATION: $superfam";
			print SPFAMCANDIDS "$idCandid\n";
			my $qttToPrint = scalar(@arrayPrint);
			for (my $j = 0; $j < $qttToPrint; $j++) { print SPFAMCANDIDS "$arrayPrint[$j]\n"; }
			print SPFAMCANDIDS "###\n";

			for (my $j = 0; $j < $qttToPrint; $j++) { $idCandid .= "\n$arrayPrint[$j]"; } 
			push (@candidAllSuperfam, {line => $idCandid, from => $startCandid});
		}
	} # WHILE ($i < $qttSpfam)
## END of generating candidates of each superfamily

	close (SPFAMCANDIDS);
} # FOREACH $superfam (@superfamilies)

## Generating the final candidates for all superfamilies together:
print TOOLCANDIDS "Final candidates of HMMER, with the predictions used to generate each candidate.\n";
print TOOLCANDIDS "Maximum distance between two predictions to consider them inside the same candidate: $maxDistPreds.\n";
if ($tool eq "HMMER") { print TOOLCANDIDS "Filter for e-values: $usedFilter.\n\n"; }

my @auxSorted = sort{ $a->{from} <=> $b->{from} } @candidAllSuperfam;
my @sortedCandidAllSuperfam = ();
foreach my $lineAux (@auxSorted) { push (@sortedCandidAllSuperfam, $lineAux->{line}); }

my $qttCandid = scalar(@sortedCandidAllSuperfam);
for (my $i = 0; $i < $qttCandid-1; $i++) {
    for (my $j = $i+1; $j < $qttCandid; $j++) {
	if ($sortedCandidAllSuperfam[$i] =~ /-->OUT/) { last; }
	if ($sortedCandidAllSuperfam[$j] !~ /-->OUT/) {
		my ($resp, $sense1, $sense2) = verifyOverlap ($tool, $sortedCandidAllSuperfam[$i], $sortedCandidAllSuperfam[$j]);
		if    ($resp eq "II") { $sortedCandidAllSuperfam[$i] .= "-->OUT"; }
		elsif ($resp eq "JJ") { $sortedCandidAllSuperfam[$j] .= "-->OUT"; }
		elsif ($sense1 eq $sense2) { last; }
	}
    }
}

my $numCandid = 0;
for (my $i = 0; $i < $qttCandid; $i++) {
    if ($sortedCandidAllSuperfam[$i] !~ /-->OUT/) {
	$numCandid++;
# for HMMER: Candidate_num - FROM: ff - TO: tt - LENGTH: ll - EVALUE: ev - SENSE: d/r - CLASSIFICATION: sf 
# for RM:    Candidate_num - FROM: ff - TO: tt - LENGTH: ll - SWSCORE: sc - SENSE: d/r - CLASSIFICATION: sf
	if ($sortedCandidAllSuperfam[$i] =~ /Candidate_\d+ - (.*)- $metrics: .* - SENSE: (.*)/) {
		my $idCandid = "CANDIDATE_$numCandid - $1- SENSE: $2";
		print TOOLCANDIDS "$idCandid\n";
		print "$idCandid\n";

#		write the predictions used to generate the candidate
		my @arraySplit = split '\n',$sortedCandidAllSuperfam[$i];
		my $qttSepara = scalar(@arraySplit);
		for (my $j = 1; $j < $qttSepara; $j++) {
			print TOOLCANDIDS "$arraySplit[$j]\n";
			print "$arraySplit[$j]\n";
		}
		print TOOLCANDIDS "\n";
		print "###\n";
	}
    }
}

close (TOOLCANDIDS);

