# Developed by Carlos Fischer - 11.01.2021
# To generate the final candidates of RPS-Blast, for all superfamilies.
# It generates also a separate file with the candidates with all superfamilies, for each chromosome

# Usage: perl finalCandidsRpsBlast.pl CHROMO FILTER

##############
# WARNING: THIS SCRIPT IS TO BE USED **ONLY** TO REPRODUCE THE RESULTS DESCRIBED IN THE MAIN TEXT AND THE SUPPLEMENTARY MATERIAL FILE
##############

# It generates initial results used to produce Tables S1-S2 and S7-S8

# It is launched by CombTEs.pl


###########################################################################################

use strict;
use warnings;

use Cwd qw(getcwd);
use lib getcwd(); 

use ParamsGeneral  qw(@superfamilies);
use ParamsRpsblast qw(%domains $distPredsRPSB);

###########################################################################################

my $chromo         = $ARGV[0];
my $filterRpsBlast = $ARGV[1];


my $fileConsDoms = "Results_Rpsblast/ConservedDomains_NoRedund-$chromo.pred"; # RPS-Blast predictions
open (PREDFILE, $fileConsDoms) or die "\nCan't open $fileConsDoms!!!\n\n";
my @domainsRpsb = <PREDFILE>;
close (PREDFILE);

my $qttDoms = scalar(@domainsRpsb);

my $finalCandids = "Results_Rpsblast/finalCandidates_RpsBlast-$chromo\_$filterRpsBlast.txt";
open (CANDIDS, ">$finalCandids") or die "Can't open $finalCandids";
print CANDIDS "Final candidates of RPS-Blast, with the domain predictions used to generate each candidate.\n";
print CANDIDS "Maximum distance between two predictions to consider them inside the same candidate: $distPredsRPSB.\n";
print CANDIDS "Filter for e-values: $filterRpsBlast.\n\n";

my $newCandid = "yes";
my $numCandid = 0;
my $i = 0;
my ($superfam, $startCandid, $endCandid, $senseCandid, $spfamCandid, @arrayToPrint);
while ($i < $qttDoms) {
	my $line = $domainsRpsb[$i]; chomp $line;
#	DOMAIN--dom---FROM--ff---TO--tt---LENGTH--ll---EVALUE--eval---SCORE--sc---SENSE--D/R
	if ($line =~ /DOMAIN--(.*)---FROM--(\d+)---TO--(\d+)---LENGTH--.*---EVALUE--(.*)---SCORE--.*---SENSE--(.*)/) {
		my $dom    = $1;
		my $from   = $2;
		my $to     = $3;
		my $evalue = $4;
		my $sense  = $5;

		if ($evalue <= $filterRpsBlast) {
			if ($dom eq "rve") { $superfam = "inconclusive"; } # it may be a prediction from several superfamilies
			else {
				foreach my $spfam (@superfamilies) {
					if ($dom =~ $domains{$spfam}) { $superfam = $spfam; }
				}
			}

			if ($newCandid eq "yes") {
				$startCandid = $from;
				$endCandid   = $to;
				$senseCandid = $sense;
				$spfamCandid = $superfam;
				@arrayToPrint = ();
				push (@arrayToPrint, $line);
				$newCandid = "no";
				$i++;
			}
			else { # ($newCandid eq "NO")
				if ( ($sense eq $senseCandid) and ( ($superfam eq $spfamCandid) or ($superfam eq "inconclusive") or ($spfamCandid eq "inconclusive") ) and (($from - $endCandid) <= $distPredsRPSB) ) {
			# a new candidate when: "different sense", "different superfams", or "dist(from-endCandid) > $distPredsRPSB".
					if ($spfamCandid eq "inconclusive") { $spfamCandid = $superfam; }
					if ($to > $endCandid) { $endCandid = $to; }
					push (@arrayToPrint, $line);
					$i++;
				}
				else { $newCandid = "yes"; } # found a new candidate: write the current one.
			} # ELSE { # $newCandid eq "NO"
		} # IF ($evalue <= $filterRpsBlast)
		else { $i++; }

		if ( ($newCandid eq "yes") or ($i == $qttDoms) ) {
			my $qttToPrint = scalar(@arrayToPrint);
			if ($qttToPrint != 0) {
				$numCandid++;
				my $lengthCandid = $endCandid - $startCandid + 1;
				my $idCandid = "CANDIDATE_$numCandid - FROM: $startCandid - TO: $endCandid - LENGTH: $lengthCandid - SENSE: $senseCandid - CLASSIFICATION: $spfamCandid";
				print CANDIDS "$idCandid\n";
				print "$idCandid\n";

				for (my $j = 0; $j < $qttToPrint; $j++) {
					print CANDIDS "$arrayToPrint[$j]\n";
					print "$arrayToPrint[$j]\n";
				}
				print CANDIDS "\n";
				print "###\n";
			} # IF ($qttToPrint != 0)
		} # IF ( ($newCandid eq "yes") or ($i == $qttDoms) )

	} # IF ($line =~ /DOMAIN--(.*)---FROM-- ...
	else { $i++; }

} # WHILE ($i < $qttDoms)

close (CANDIDS);

