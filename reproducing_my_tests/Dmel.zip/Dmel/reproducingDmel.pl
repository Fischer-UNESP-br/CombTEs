# Developed by Carlos Fischer - 18.01.2021
# Used to launch the necessary scripts to reproduce the results described in the main text and the supplementary material
# Usage: perl reproducingDmel.pl

##############
# WARNING: THIS SCRIPT IS TO BE USED **ONLY** TO REPRODUCE THE RESULTS DESCRIBED IN THE MAIN TEXT AND THE SUPPLEMENTARY MATERIAL FILE
##############


# scripts to be launched by reproducingDmel.pl:

print "Extracting predictions from HMMER ...\n";
system("perl extractHmmerRM_HMMER.pl");
print "\nExtracting predictions from HMMER - for pHMMs Complete ...\n";
system("perl extractHmmerRM_HMMER_Complete.pl");

print "\nExtracting predictions from RepeatMasker ...\n";
system("perl extractHmmerRM_RM.pl");

print "\nExtracting predictions from RPS-Blast ...\n";
system("perl extractRPSB.pl");


print "\nRunning CombTEs ...\n";
system("perl CombTEs.pl");
print "\nRunning CombTEs_Complete ...\n";
system("perl CombTEs_Complete.pl");
 
print "\nRunning compareCandidatesDmel ...\n";
system("perl compareCandidatesDmel.pl");
print "\nRunning compareCandidatesDmel_Complete ...\n";
system("perl compareCandidatesDmel_Complete.pl");

print "\nRunning compareFNsDmel ...\n";
system("perl compareFNsDmel.pl");
print "\nRunning compareFNsDmel_Complete ...\n";
system("perl compareFNsDmel_Complete.pl");

print "\nRunning compareFPsDmel ...\n";
system("perl compareFPsDmel.pl");
print "\nRunning compareFPsDmel_Complete ...\n";
system("perl compareFPsDmel_Complete.pl");

print "\nRunning compareGroupsDmel ...\n";
system("perl compareGroupsDmel.pl");
print "\nRunning compareGroupsDmelGoodMetrics ...\n";
system("perl compareGroupsDmelGoodMetrics.pl");

print "\nDone!\n\n";


