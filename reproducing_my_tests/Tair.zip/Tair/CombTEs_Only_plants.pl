# Developed by Carlos Fischer - 11.01.2021
# Used to combine the final candidates of all used tools, for all superfamilies of interest, and produce their final classification.
# Usage: perl CombTEs_Only_plants.pl

##############
# WARNING: THIS SCRIPT IS TO BE USED **ONLY** TO REPRODUCE THE RESULTS DESCRIBED IN THE MAIN TEXT AND THE SUPPLEMENTARY MATERIAL FILE
##############

# It generates initial results used to produce Tables S5-S6.

# This script launches the "finalCandidsHmmerRM_Only_plants.pl" script, which generates the final candidates of HMMER and RepeatMasker, for all considered superfamilies.


###########################################################################################

use strict;
use warnings;

use Cwd qw(getcwd);
use lib getcwd(); 

use ParamsGeneral qw(@superfamilies @combClassif @tools @outFileNames %filterTools $distBetweenCands);

my @usedFiltersHMMER = (100, 100, 100, 100, 100, 100, 1.0e-03, 1.0e-05, 1.0e-10, 1.0e-15, 1.0e-20, 1.0e-30, 1.0e-03, 1.0e-05, 1.0e-10, 1.0e-20, 1.0e-30);
my @usedFiltersRM    = (225, 230, 250, 300, 350, 360, 500, 580, 730, 1300, 1600, 2200, 410, 440, 550, 720, 830);
my $qttFiltersHMMER = scalar(@usedFiltersHMMER);
my $qttFiltersRM    = scalar(@usedFiltersRM);
if ($qttFiltersHMMER != $qttFiltersRM) { die "NO MATCH IN NUMBERS OF FILTERS!!"; }

my @classSpfam  = (@superfamilies);

my @chromosomes = (1, 2, 3, 4, 5);

###########################################################################################


foreach my $chromo (@chromosomes) {

print "CHROMO $chromo:\n";

    for (my $iFilt = 0; $iFilt < $qttFiltersHMMER; $iFilt++) {
	$filterTools{'HMMER'}        = $usedFiltersHMMER[$iFilt];
	$filterTools{'RepeatMasker'} = $usedFiltersRM[$iFilt];

print "\tUSED FILTERS: $filterTools{'HMMER'} - $filterTools{'RepeatMasker'}\n";

	my $usedFilters = "$filterTools{'HMMER'}-$filterTools{'RepeatMasker'}";

	my $finalFile = "X_FinalClassification/Only_plants/FinalClassification-$chromo\_$usedFilters.txt";
	open (CLASS, ">$finalFile") or die "Can't open $finalFile";

	print CLASS "Final classification for \"HMMER\", \"RepeatMasker\".\n";
	print CLASS "Used filters: **HMMER = $filterTools{'HMMER'}**, **RepeatMasker = $filterTools{'RepeatMasker'}**.\n";
	print CLASS "Maximum distance from a candidate to the next one to consider them inside the same FINAL GROUP: $distBetweenCands.\n\n";

### FOR FILES NAMED "ONE" AND "TWO"
	my %filehandles = ();
	foreach my $fileName (@outFileNames) {
		my $fileFinders = "X_FinalClassification/Only_plants/FinalClassification_$fileName-$chromo\_$usedFilters.txt";
		open (my $fh, ">", "$fileFinders") or die "Can't open $fileFinders";
		$filehandles{$fileName} = $fh;
		print $fh "This file shows the groups produced by $fileName tool(s)\n\n";
	}

## insertion of ALL candidates (of ALL superfamilies) from ALL tools in "@allCandid" for FINAL classification
	my @allCandid = ();
	foreach my $tool (@tools) {
		my @candidSpfam = ();
    if    ($tool eq "HMMER")	   { @candidSpfam = `perl finalCandidsHmmerRM_Only_plants.pl HMMER $chromo $filterTools{'HMMER'}`; }
    elsif ($tool eq "RepeatMasker"){ @candidSpfam = `perl finalCandidsHmmerRM_Only_plants.pl RepeatMasker $chromo $filterTools{'RepeatMasker'}`; }

		my ($from, $lineCand);
		foreach my $line (@candidSpfam) {
			if ($line =~ /FROM: (\d+) - TO/) {
				$from = $1;
				chomp $line;
				$lineCand = "\t$line\t\t$tool\n";
			}
			elsif ($line =~ /PREDIC/) { $lineCand .= "\t\t$line"; }
			elsif ($line =~ /###/) {
				chomp $lineCand;
				push (@allCandid, {line => $lineCand, from => $from});
			}
		}
	} # FOREACH my $tool (@tools)

##    sorting the candidates
	my @auxSorted = sort{ $a->{from} <=> $b->{from} } @allCandid;
	my @sortedAllCandid = ();
	foreach my $lineAux (@auxSorted) { push (@sortedAllCandid, $lineAux->{line}); }

########### producing the groups of the final classification
	my %classif = ();
	foreach my $clsf (@classSpfam) { $classif{$clsf} = 0; }

	my %toolFinder = ();
	foreach my $tool (@tools) { $toolFinder{$tool} = 0; }

	my %typeClassFinal = ();
	foreach my $fileName (@outFileNames) {
		foreach my $comb (@combClassif) { $typeClassFinal{$fileName.$comb} = 0; }
	}

	my $qttCandid = scalar(@sortedAllCandid);

	my $group      = 0;
	my @arrayGroup = ();
	my $fromGroup  = 0;
	my $toGroup    = 0;
	my $newGroup   = "yes";
	my $i = 0;
	my ($from1, $to1, $sense1, $senseGroup, $from2, $sense2);
	while ($i < $qttCandid) {
		push (@arrayGroup, $sortedAllCandid[$i]);

# from the input files:
#	CANDIDATE_num - FROM: ff - TO: tt - LENGTH: ll - SENSE: d/r - CLASSIFICATION: Sf \n 
#	PREDIC---FROM--ff--- ...	(OR)
#	DOMAIN--dom---FROM-- ...
		if ($sortedAllCandid[$i] =~ /FROM: (\d+) - TO: (\d+) - LENGTH: \d+ - SENSE: (\w+) - CLASSIFICATION: (\w+)\t\t(\w+)\n\t\t(PREDIC)/) {
			$from1  = $1;
			$to1    = $2;
			$sense1 = $3;
			my $class1 = $4;
			$classif{$class1} = 1;
			my $tool1  = $5;
			$toolFinder{$tool1} = 1;
		}

		if ($newGroup eq "yes") {
			$fromGroup  = $from1;
			$senseGroup = $sense1;
			$newGroup   = "no";
		}

		if ($to1 > $toGroup) { $toGroup = $to1; }

		if ( ($i+1) < $qttCandid ) { # there is a next candidate
			if ($sortedAllCandid[$i+1] =~ /FROM: (\d+) - TO: .* - SENSE: (.*) - CLASSIFICATION/) {
				$from2  = $1;
				$sense2 = $2;
			}
		}

		if ( (($from2-$toGroup) > $distBetweenCands) or ($sense2 ne $senseGroup) or (($i+1) == $qttCandid) ) {
# if (distance between next candidate and current GROUP is higher than "$distBetweenCands") OR (they are in different senses) OR (current candidate is the last one), then a new GROUP must be formed: write the current GROUP in the output files.
			my $finalClass = "";
			my $finalTools = "";
			$group++;
			my $lenGroup = $toGroup - $fromGroup + 1;

			foreach my $clsf (@superfamilies) {
				if ($classif{$clsf} == 1) {
					if ($finalClass eq "")  { $finalClass = $clsf; }
					else			{ $finalClass .= "/$clsf"; }
				}
			}
			foreach my $clsf (@classSpfam) { $classif{$clsf} = 0; }

			my $numTools = 0;
			foreach my $tool (@tools) {
				if ($toolFinder{$tool} == 1) {
					if ($finalTools eq "")  { $finalTools = $tool; }
					else			{ $finalTools .= " / $tool"; }
					$numTools++;
				}
				$toolFinder{$tool} = 0;
			}
			my $indx = $numTools - 1;
			my $file = $outFileNames[$indx];
			my $FILEtoWRITE = $filehandles{$file};

			my $descrGroup = "GROUP $group - FROM: $fromGroup - TO: $toGroup - LENGTH: $lenGroup - SENSE: $senseGroup - CLASS: $finalClass - TOOL(S): $finalTools\n";
			print CLASS $descrGroup;
			print $FILEtoWRITE $descrGroup;

			my $qttArrayGroup = scalar(@arrayGroup);
			for (my $j = 0; $j < $qttArrayGroup; $j++) {
			   print CLASS "$arrayGroup[$j]\n";
			   print $FILEtoWRITE "$arrayGroup[$j]\n";
			}
			print CLASS "\n";
			print $FILEtoWRITE "\n";

			@arrayGroup = ();
			$fromGroup  = 0;
			$toGroup    = 0;
			$newGroup   = "yes";

			$typeClassFinal{$file.$finalClass}++;
		} # IF ( (($from2-$toGroup) > $distBetweenCands) or ...

		$i++;
	} # WHILE ($i < $qttCandid)
########### END of producing the groups of the final classification


## extra output info:
	print CLASS "#####################################################\n\n";
	print CLASS "SUMMARY OF THE GENERATED GROUPS:\n\n";

	foreach my $fileName (@outFileNames) {
		my $qttGroup = 0;
		foreach my $comb (@combClassif) { $qttGroup += $typeClassFinal{$fileName.$comb}; }
		print CLASS "Groups generated by $fileName tool(s): $qttGroup\n";
		print CLASS "   Final classification:\n";
		foreach my $comb (@combClassif) { print CLASS "      - $comb: $typeClassFinal{$fileName.$comb}\n"; }
		print CLASS "\n";
	}

## closing all output files
	foreach my $fileName (@outFileNames) { close ($filehandles{$fileName}); }
	close (CLASS);

    } # FOR ($iFilt = 0; $iFilt < $qttFiltersHMMER; $iFilt++)
} # FOREACH $chromo (@chromosomes)

