# Developed by Carlos Fischer - 11.01.2021
# Used to compare candidates from each tool with true annotation of TAIR
# Usage: perl compareCandidatesTair_Only_plants.pl

##############
# WARNING: THIS SCRIPT IS TO BE USED **ONLY** TO REPRODUCE THE RESULTS DESCRIBED IN THE MAIN TEXT AND THE SUPPLEMENTARY MATERIAL FILE
##############

# The results produced here are used to generate Tables S5-S6


##############################################
@usedFiltersHMMER = (100, 1.0e-03, 1.0e-05, 1.0e-10, 1.0e-15, 1.0e-20, 1.0e-30);
@usedFiltersRM    = (225, 230, 250, 300, 350, 360, 500, 580, 730, 1300, 1600, 2200, 410, 440, 550, 720, 830);

$minOverl = 30;

@tools = ("HMMER", "RepeatMasker");

@superfamilies = ("Copia", "Gypsy");

@chromosomes = (1, 2, 3, 4, 5);

##############################################


foreach $chromo (@chromosomes) {
	print "CHROMO: $chromo\n";

	@allAnnotation = ();
	foreach $superfam (@superfamilies) {
		$inTrue = "Annotation/$superfam/tair-11-trueAnnotationLTRs-$superfam-$chromo.txt";
		open (INTRUE,"$inTrue") || die "Can't open $inTrue";

		while (not eof INTRUE) {
			$line = readline(INTRUE);
			if ($line =~ /FROM--(\d+)---TO/) { push (@allAnnotation, {line => $line, from => $1}); }
		}
		close (INTRUE);
	}
	@auxSorted = ();
	@auxSorted = sort{ $a->{from} <=> $b->{from} } @allAnnotation;
	@sortedAllAnnotation = ();
	foreach $lineAux (@auxSorted) { push (@sortedAllAnnotation, $lineAux->{line}); }

	$Annot = 0;
	@teTrue = ();
	foreach $line (@sortedAllAnnotation) {
		chomp $line;
#	Annot---CHROMO--chr---FROM--ff---TO--tt---LENGTH--ll---SENSE--d/r---CLASSIF--spfam----->ATCOPIA24
		if ($line =~ /FROM--(\d+)---TO--(\d+)---LENGTH--\d+---SENSE--(\w+)---CLASSIF--(\w+)----->/){
			$Annot++;
			$teTrue[$Annot]{"from"}   = $1;
			$teTrue[$Annot]{"to"}     = $2;
			$teTrue[$Annot]{"sense"}  = $3;
			$teTrue[$Annot]{"superfam"} = $4;
			$teTrue[$Annot]{"alldescr"} = $line;
		}
	} # FOREACH $line (@sortedAllAnnotation) {

	foreach $tool (@tools) {
	    print "\t$tool\n";

	    if    ($tool eq "RepeatMasker") { @usedFilters = @usedFiltersRM; }
	    elsif ($tool eq "HMMER")        { @usedFilters = @usedFiltersHMMER; }

	    $qttFilters = scalar(@usedFilters);
	    for ($iFilt = 0; $iFilt < $qttFilters; $iFilt++) {
		$filterTool = $usedFilters[$iFilt];
		print "\t\t$filterTool:\n";

		for ($nextAnnot = 1; $nextAnnot <= $Annot; $nextAnnot++) { $teTrue[$nextAnnot]{"detected"} = 0; } 

		$out = "Results_$tool/Only_plants/XX_comparedCandidates_$tool-$chromo-$filterTool.cmp";
		open (OUT,">$out") || die "Can't open $out";

		$inPred = "Results_$tool/Only_plants/finalCandidates_$tool-$chromo\_$filterTool.txt";
		open (INPRED,"$inPred") || die "Can't open $inPred";

		$pred = 0;
		@predicted = ();
		while (not eof INPRED) {
			$line = readline(INPRED);
#			CANDIDATE_1 - FROM: ff - TO: tt - LENGTH: ll - SENSE: d/r - CLASSIFICATION: spfam
			if ($line =~ /CANDIDATE/) {
				chomp $line;
				$pred += 1;
				$predicted[$pred]{"alldescr"} = $line;
				$predicted[$pred]{"correct"} = 0;
			}
		}
		close(INPRED);

		for ($nextAnnot = 1; $nextAnnot <= $Annot; $nextAnnot++) {
			for ($nextPred = 1; $nextPred <= $pred; $nextPred++) {
			   $line = $predicted[$nextPred]{"alldescr"};
			   chomp $line;
#			CANDIDATE_1 - FROM: ff - TO: tt - LENGTH: ll - SENSE: d/r - CLASSIFICATION: spfam
			   if ($line =~ /FROM: (\d+) - TO: (\d+) - LENGTH: \d+ - SENSE: (\w+) - CLASSIFICATION: (.*)/) {
				$fromPred   = $1;
				$toPred     = $2;
				$sensePred  = $3;
				$classPred  = $4;
			   }

			   if ( ($sensePred eq $teTrue[$nextAnnot]{"sense"}) and ($classPred eq $teTrue[$nextAnnot]{"superfam"}) ) {
				if (
			   not (
				($fromPred >= $teTrue[$nextAnnot]{"to"}) or ($teTrue[$nextAnnot]{"from"} >= $toPred) or
( ($toPred <= $teTrue[$nextAnnot]{"to"}) and ($toPred > $teTrue[$nextAnnot]{"from"}) and (($toPred - $teTrue[$nextAnnot]{"from"}) < $minOverl) ) or
( ($fromPred >= $teTrue[$nextAnnot]{"from"}) and ($fromPred < $teTrue[$nextAnnot]{"to"}) and (($teTrue[$nextAnnot]{"to"} - $fromPred) < $minOverl) )
			)
				) {
					$teTrue[$nextAnnot]{"detected"} += 1;
					$predicted[$nextPred]{"correct"} += 1;
					print OUT "Annotated:\t".$teTrue[$nextAnnot]{"alldescr"}."\n";
					print OUT "Predicted:\t".$predicted[$nextPred]{"alldescr"}."\n\n";
				}
			   }
			} # FOR ($nextPred = 1; $nextPred ...
		} # FOR ($nextAnnot = 1; $nextAnnot ...

		print OUT "TOTAL OF TRUE ANNOTATED: $Annot\n\n";
		print OUT "TOTAL OF PREDICTION: $pred\n\n";

		$FP = 0;
		print OUT "FALSE POSITIVE PREDICTED (NOT ANNOTATED):\n";
		for ($next = 1; $next <= $pred; $next++) {
			if ($predicted[$next]{"correct"} == 0) {
				print OUT $predicted[$next]{"alldescr"}."\n";
				$FP += 1;
			}
		}
		print OUT "\n";

		$FN = 0;
		print OUT "TRUE ANNOTATED NOT PREDICTED:\n";
		for ($next = 1; $next <= $Annot; $next++) {
			if ($teTrue[$next]{"detected"} == 0) {
				print OUT $teTrue[$next]{"alldescr"}."\n";
				$FN += 1;
			}
		}
		print OUT "\n";

		$anotadoComparadoMaisDeUmaVez = 0;
		print OUT "ANNOTATED PREDICTED TWICE OR MORE:\n";
		for ($next = 1; $next <= $Annot; $next++) {
			if ($teTrue[$next]{"detected"} > 1) {
				print OUT $teTrue[$next]{"alldescr"}."\n";
				$anotadoComparadoMaisDeUmaVez += $teTrue[$next]{"detected"} - 1;
				print OUT $teTrue[$next]{"detected"}." vezes\n";
			}
		}
		print OUT "TOTAL OF ANNOTATED PREDICTED TWICE OR MORE: $anotadoComparadoMaisDeUmaVez\n";
		print OUT "\n";

		$preditoComparadoMaisDeUmaVez = 0;
		print OUT "PREDICTED COMPARED TWICE OR MORE:\n";
		for ($next = 1; $next <= $pred; $next++) {
			if ($predicted[$next]{"correct"} > 1) {
				print OUT $predicted[$next]{"alldescr"}."\n";
				$preditoComparadoMaisDeUmaVez += $predicted[$next]{"correct"} - 1;
				print OUT $predicted[$next]{"correct"}." vezes\n";
			}
		}
		print OUT "TOTAL OF PREDICTED COMPARED TWICE OR MORE: $preditoComparadoMaisDeUmaVez\n";
		print OUT "\n";

		$predCorrigido = $pred - $anotadoComparadoMaisDeUmaVez;
		$annotCorrigido = $Annot - $preditoComparadoMaisDeUmaVez;
		$TP = $predCorrigido - $FP;

		if ($TP+$FP == 0) {$precision = 0;} else {$precision = $TP/($TP+$FP);}
		if ($TP+$FN == 0) {$recall = 0;} else {$recall = $TP/($TP+$FN);}
		if ($precision+$recall == 0) {$fmeasure = 0;} else {$fmeasure = 2*($precision*$recall)/($precision+$recall);}


		print OUT "TOTAL OF TRUE ANNOTATED (original): $Annot\n";
		print OUT "TOTAL OF TRUE ANNOTATED (corrected): $annotCorrigido\n";
		print OUT "TOTAL OF PREDICTION (original): $pred\n";
		print OUT "TOTAL OF PREDICTION (corrected): $predCorrigido\n";
		print OUT "TP: $TP \n";
		print OUT "FP: $FP \n";
		print OUT "FN: $FN \n";
		print OUT "\n";

		print OUT "Precision = $precision\n";
		print OUT "Recall = $recall\n";
		print OUT "F-measure = $fmeasure\n";

		close(OUT);

		$result = "Results_$tool/Only_plants/XX_Results_corrected_comparedCandidates_$tool-$filterTool.txt";
		open (OUT2,">>$result") || die "Can't open $result";

		print OUT2 "CHROMOSOME: $chromo\n";
		print OUT2 "\tTOTAL OF TRUE ANNOTATED (original): $Annot\n";
		print OUT2 "\tTOTAL OF TRUE ANNOTATED (corrected): $annotCorrigido\n";
		print OUT2 "\tTOTAL OF PREDICTION (original): $pred\n";
		print OUT2 "\tTOTAL OF PREDICTION (corrected): $predCorrigido\n";
		print OUT2 "\tTP: $TP\n";
		print OUT2 "\tFP: $FP\n";
		print OUT2 "\tFN: $FN\n";
		print OUT2 "\n";

		print OUT2 "\tPrecision = $precision\n";
		print OUT2 "\tRecall = $recall\n";
		print OUT2 "\tF-measure = $fmeasure\n";
		print OUT2 "\n\n";

		close(OUT2);
	    } # FOR ($iFilt = 0; $iFilt < $qttFiltersHMMER; $iFilt++)

	} # FOREACH $tool(@tools){
} # FOREACH $chromo (@chromosomes) {

