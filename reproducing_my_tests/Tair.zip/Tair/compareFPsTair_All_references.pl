# Developed by Carlos Fischer - 11.01.2021
# Used to compare FPs from each method in each chromosome
# Usage: perl compareFPsTair_All_references.pl

##############
# WARNING: THIS SCRIPT IS TO BE USED **ONLY** TO REPRODUCE THE RESULTS DESCRIBED IN THE MAIN TEXT AND THE SUPPLEMENTARY MATERIAL FILE
##############

# The results produced here are used to generate Tables S3-S4


##############################################
@usedFiltersHMMER = (100, 100, 100, 100, 100, 1.0e-03, 1.0e-05, 1.0e-10, 1.0e-20, 1.0e-30, 1.0e-03, 1.0e-05, 1.0e-10, 1.0e-20, 1.0e-30);
@usedFiltersRM = (225, 230, 250, 300, 350, 2000, 2100, 2250, 2450, 2650, 700, 900, 1000, 1500, 1800);
$qttFiltersHMMER = scalar(@usedFiltersHMMER);
$qttFiltersRM    = scalar(@usedFiltersRM);
if ($qttFiltersHMMER != $qttFiltersRM) { die "NO MATCH IN NUMBERS OF FILTERS!!"; }

$minOverl = 30;
$varExtr  = 50;

$tool1 = "HMMER";
$tool2 = "RepeatMasker";

@chromosomes = (1, 2, 3, 4, 5);

##############################################


for ($iFilt = 0; $iFilt < $qttFiltersHMMER; $iFilt++) {

    $filterHMM = $usedFiltersHMMER[$iFilt];
    $filterRM  = $usedFiltersRM[$iFilt];

    print "$filterHMM and $filterRM:\n";

    $outGeral = "X_Tables_S3-S4/Summary_FPs_$tool1\_$filterHMM-$tool2\_$filterRM.cmp";
    open (OUTGERAL,">$outGeral") || die "Can't open $outGeral";
    print OUTGERAL "Summary of FP comparison from \"$tool1\" and \"$tool2\" tools\n";
    print OUTGERAL "Used filters: **$tool1 = $filterHMM** and **$tool2 = $filterRM**\n\n";

    $totalGeralFPs1 = 0;
    $totalGeralFPs2 = 0;
    $totalGeralFPsExcl1 = 0;
    $totalGeralFPsExcl2 = 0;
    $totalGeralFPsRepet1 = 0;
    $totalGeralFPsRepet2 = 0;
    $totalGeralFPsComuns1 = 0;
    $totalGeralFPsComuns2 = 0;


    foreach $chromo (@chromosomes) {
	print "\t$chromo\n";

	$comp1 = "Results_$tool1/All_references/XX_comparedCandidates_$tool1-$chromo-$filterHMM.cmp";
	open (COMP1, $comp1) || die "Can't open $comp1";

	$line = readline(COMP1); chomp $line;
	while ($line !~ /FALSE POSITIVE PREDICTED/) { $line = readline(COMP1); }
	@fps1 = ();
	$line = readline(COMP1);
	while ($line ne "\n") {
		chomp $line;
		push (@fps1, $line);
		$line = readline(COMP1);
	}
	close(COMP1);

	$comp2 = "Results_$tool2/All_references/XX_comparedCandidates_$tool2-$chromo-$filterRM.cmp";
	open (COMP2, $comp2) || die "Can't open $comp2";

	$line = readline(COMP2); chomp $line;
	while ($line !~ /FALSE POSITIVE PREDICTED/) { $line = readline(COMP2); }
	@fps2 = ();
	$line = readline(COMP2);
	while ($line ne "\n") {
		chomp $line;
		push (@fps2, $line);
		$line = readline(COMP2);
	}
	close(COMP2);

	$out = "X_FPs/All_references/FPs_$chromo\_$tool1\_$filterHMM-$tool2\_$filterRM.cmp";
	open (OUT,">$out") || die "Can't open $out";

	print OUT "FPs COMMON FOR CHROMO $chromo\n\n";

	$qtt1 = scalar(@fps1);
	$qtt2 = scalar(@fps2);

	$repetFPs1 = 0;
	$repetFPs2 = 0;

	for ($i = 0; $i < $qtt1; $i++) {
		$fp1 = $fps1[$i];
#		CANDIDATE_1 - FROM: ff - TO: tt - LENGTH: ll - SENSE: d/r - CLASSIFICATION: spfam
		if ($fp1 =~ /FROM: (\d+) - TO: (\d+) - LENGTH: \d+ - SENSE: (\w+) - CLASSIFICATION: (\w+)/) {
			$from1  = $1;
			$to1    = $2;
			$sense1 = $3;
			$spfam1 = $4;

			for ($j = 0; $j < $qtt2; $j++) {
			    $fp2 = $fps2[$j];
			    if ($fp2 =~ /FROM: (\d+) - TO: (\d+) - LENGTH: \d+ - SENSE: (\w+) - CLASSIFICATION: (\w+)/) {
				$from2  = $1;
				$to2    = $2;
				$sense2 = $3;
				$spfam2 = $4;

				if ( ($sense1 eq $sense2) and ($spfam1 eq $spfam2) ) {
				    if ( ($from2 <= $to1) or ($to2 >= $from1) ) { 
					if (
		    (abs($from1-$from2) <= $varExtr) or (abs($to1-$to2) <= $varExtr) or # small variation in corresponding extremities
		    (($from1 < $from2) and ($to2 <  $to1)) or			     # seq_2 inside seq_1
		    (($from2 < $from1) and ($to1 <  $to2)) or			     # seq_1 inside seq_2
		    (($from1 < $from2) and (($to1 - $from2) >= $valueOverlap)) or    # overlap >= $valueOverlap
		    (($to2   < $to1)   and (($to2 - $from1) >= $valueOverlap))
		   ) {
						print OUT "HMMER: $fps1[$i]\n";
						print OUT "RM  : $fps2[$j]\n\n";

						if ($fps1[$i] =~ /comum/) { $repetFPs1++; }
						if ($fps2[$j] =~ /comum/) { $repetFPs2++; }
						$fps1[$i] .= "--comum";
						$fps2[$j] .= "--comum";

					} # IF ( (abs($from1-$from2) <= $varExtr) or ....

				    } # IF ( ($from2 < $to1) or ($to2 > $from1) )
				} # IF ( ($sense1 eq $sense2) and ($spfam1 eq $spfam2) )
			    }
			} # FOR ($j = 0; $j < $qtt2; $j++)
		} # IF ($fp1 =~ /CLASSIF
	} # FOR ($i = 0; $i < $qtt1; $i++)

	print OUT "\n\n";
	print OUT "FPs exclusive for $tool1:\n";
	$exclFP1 = 0;
	foreach $fp1 (@fps1) {
		if ($fp1 !~ /comum/) { $exclFP1++; print OUT "$fp1\n"; }
	}

	print OUT "\n\n";
	print OUT "FPs exclusive for $tool2:\n";
	$exclFP2 = 0;
	foreach $fp2 (@fps2) {
		if ($fp2 !~ /comum/) { $exclFP2++; print OUT "$fp2\n"; }
	}

	$comumFPs1 = $qtt1 - $exclFP1 - $repetFPs2;
	$comumFPs2 = $qtt2 - $exclFP2 - $repetFPs1;

	print OUT "\n-------------------------------------------------------\n\n";
	print OUT "FOR $tool1:\n";
	print OUT "\tQTT OF FPs:    $qtt1\n";
	print OUT "\tFPs EXCLUSIVE: $exclFP1\n";
	print OUT "\tFPs REPEATED:  $repetFPs1\n";
	print OUT "\tFPs COMMOM:    $comumFPs1\n";
	print OUT "FOR $tool2:\n";
	print OUT "\tQTT OF FPs:    $qtt2\n";
	print OUT "\tFPs EXCLUSIVE: $exclFP2\n";
	print OUT "\tFPs REPEATED:  $repetFPs2\n";
	print OUT "\tFPs COMMON:    $comumFPs2\n\n";

	close (OUT);

	print OUTGERAL "CHROMO $chromo:\n";
	print OUTGERAL "\tFOR $tool1:\n";
	print OUTGERAL "\t\tQTT OF FPs:    $qtt1\n";
	print OUTGERAL "\t\tFPs EXCLUSIVE: $exclFP1\n";
	print OUTGERAL "\t\tFPs REPEATED:  $repetFPs1\n";
	print OUTGERAL "\t\tFPs COMMON:    $comumFPs1\n";
	print OUTGERAL "\tFOR $tool2:\n";
	print OUTGERAL "\t\tQTT OF FPs:    $qtt2\n";
	print OUTGERAL "\t\tFPs EXCLUSIVE: $exclFP2\n";
	print OUTGERAL "\t\tFPs REPEATED:  $repetFPs2\n";
	print OUTGERAL "\t\tFPs COMMON:    $comumFPs2\n\n";

	$totalGeralFPs1 += $qtt1;
	$totalGeralFPs2 += $qtt2;
	$totalGeralFPsExcl1  += $exclFP1;
	$totalGeralFPsExcl2  += $exclFP2;
	$totalGeralFPsRepet1 += $repetFPs1;
	$totalGeralFPsRepet2 += $repetFPs2;
	$totalGeralFPsComuns1 += $comumFPs1;
	$totalGeralFPsComuns2 += $comumFPs2;

    } # FOREACH $chromo (@chromosomes)

    print OUTGERAL "**************************\n\n";

    print OUTGERAL "Used filters: **$tool1 = $filterHMM** and **$tool2 = $filterRM**\n\n";

    print OUTGERAL "General total of FPs from:\n";
    print OUTGERAL "\t$tool1: $totalGeralFPs1\n";
    print OUTGERAL "\t$tool2: $totalGeralFPs2\n\n";

    print OUTGERAL "General total of FPs EXCLUSIVE of:\n";
    print OUTGERAL "\t$tool1: $totalGeralFPsExcl1\n";
    print OUTGERAL "\t$tool2: $totalGeralFPsExcl2\n\n";

    print OUTGERAL "General total of FPs REPEATED of:\n";
    print OUTGERAL "\t$tool1: $totalGeralFPsRepet1\n";
    print OUTGERAL "\t$tool2: $totalGeralFPsRepet2\n\n";

    print OUTGERAL "General total of FPs COMMON with no repetitions for:\n";
    print OUTGERAL "\t$tool1: $totalGeralFPsComuns1\n";
    print OUTGERAL "\t$tool2: $totalGeralFPsComuns2\n\n";

    $diff1 = $totalGeralFPs1 - $totalGeralFPsExcl1;
    $diff2 = $totalGeralFPs2 - $totalGeralFPsExcl2;

    $porcFPsComuns1 = int( ($diff1/$totalGeralFPs1) * 10000 )/100;
    $porcFPsComuns2 = int( ($diff2/$totalGeralFPs2) * 10000 )/100;

    print OUTGERAL "$totalGeralFPs1 - $totalGeralFPsExcl1 = $diff1 from $totalGeralFPs1 FPs from HMMER are common with FPs from RepeatMasker = $porcFPsComuns1%\n";

    $totalGeneralFPsHMMER = $totalGeralFPsComuns1 + $totalGeralFPsExcl1 + $totalGeralFPsRepet2;
    print OUTGERAL "*** Observe that: $totalGeralFPsComuns1 (FPs COMMON with no repetitions) + $totalGeralFPsExcl1 (FPs EXCLUSIVE of $tool1) + $totalGeralFPsRepet2 (FPs REPEATED of $tool2) = $totalGeneralFPsHMMER FPs from $tool1.\n";

    close (OUTGERAL);

} # FOR ($iFilt = 0; $iFilt < $qttFiltersHMMER; $iFilt++)

