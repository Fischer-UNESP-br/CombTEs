# Developed by Carlos Fischer - 18.01.2021
# Used to launch the necessary scripts to reproduce the results described in the main text and the supplementary material
# Usage: perl reproducingTair.pl

##############
# WARNING: THIS SCRIPT IS TO BE USED **ONLY** TO REPRODUCE THE RESULTS DESCRIBED IN THE MAIN TEXT AND THE SUPPLEMENTARY MATERIAL FILE
##############


# scripts to be launched by reproducingTair.pl:

print "Extracting predictions from HMMER (All_references) ...\n";
system("perl extractHmmerRM_all-refers_HMMER.pl");
print "\nExtracting predictions from HMMER (All_references) - for pHMMs Complete ...\n";
system("perl extractHmmerRM_all-refers_HMMER_Complete.pl");
print "\nExtracting predictions from HMMER (Only_plants) ...\n";
system("perl extractHmmerRM_only-plants_HMMER.pl");

print "\nExtracting predictions from RepeatMasker (All_references) ...\n";
system("perl extractHmmerRM_all-refers_RM.pl");
print "\nExtracting predictions from RepeatMasker (Only_plants) ...\n";
system("perl extractHmmerRM_only-plants_RM.pl");

print "\nRunning CombTEs_All_references ...\n";
system("perl CombTEs_All_references.pl");
print "\nRunning CombTEs_Complete_All_references ...\n";
system("perl CombTEs_Complete_All_references.pl");
print "\nRunning CombTEs_Only_plants ...\n";
system("perl CombTEs_Only_plants.pl");

print "\nRunning compareCandidatesTair_All_references ...\n";
system("perl compareCandidatesTair_All_references.pl");
print "\nRunning compareCandidatesTair_Complete_All_references ...\n";
system("perl compareCandidatesTair_Complete_All_references.pl");
print "\nRunning compareCandidatesTair_Only_plants ...\n";
system("perl compareCandidatesTair_Only_plants.pl");

print "\nRunning compareFNsTair_All_references ...\n";
system("perl compareFNsTair_All_references.pl");
print "\nRunning compareFNsTair_Complete_All_references ...\n";
system("perl compareFNsTair_Complete_All_references.pl");
print "\nRunning compareFNsTair_Only_plants ...\n";
system("perl compareFNsTair_Only_plants.pl");

print "\nRunning compareFPsTair_All_references ...\n";
system("perl compareFPsTair_All_references.pl");
print "\nRunning compareFPsTair_Complete_All_references ...\n";
system("perl compareFPsTair_Complete_All_references.pl");
print "\nRunning compareFPsTair_Only_plants ...\n";
system("perl compareFPsTair_Only_plants.pl");

print "\nDone!\n\n";


